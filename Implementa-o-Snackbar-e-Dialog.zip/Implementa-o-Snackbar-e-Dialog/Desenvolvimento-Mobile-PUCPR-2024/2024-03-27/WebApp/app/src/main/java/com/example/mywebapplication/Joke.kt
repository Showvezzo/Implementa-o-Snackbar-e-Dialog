package com.example.mywebapplication

data class Joke(val value:String)
