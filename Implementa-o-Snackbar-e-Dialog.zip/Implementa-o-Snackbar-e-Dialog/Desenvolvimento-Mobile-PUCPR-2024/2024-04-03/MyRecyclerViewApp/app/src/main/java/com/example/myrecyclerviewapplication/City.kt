package com.example.myrecyclerviewapplication

data class City(
    var name:String,
    var population:Int,
    var isCapital:Boolean = false)