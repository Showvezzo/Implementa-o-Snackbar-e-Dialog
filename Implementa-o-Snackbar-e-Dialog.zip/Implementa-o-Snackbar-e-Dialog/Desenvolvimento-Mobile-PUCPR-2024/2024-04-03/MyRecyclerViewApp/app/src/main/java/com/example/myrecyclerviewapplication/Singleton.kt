package com.example.myrecyclerviewapplication

object Singleton {
    var cities = ArrayList<City>()
}