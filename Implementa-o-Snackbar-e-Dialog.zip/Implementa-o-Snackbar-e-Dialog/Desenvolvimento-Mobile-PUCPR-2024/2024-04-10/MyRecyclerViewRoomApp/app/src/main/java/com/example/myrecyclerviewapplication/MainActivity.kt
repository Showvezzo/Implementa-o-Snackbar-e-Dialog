import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myrecyclerviewapplication.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView<ActivityMainBinding>(
            this, R.layout.activity_main)
        Singleton.setContext(this)
        val cityAdapter = CityAdapter(object : CityAdapter.OnCityClickListener{
            override fun onCityClick(view: View, position: Int) {
                Singleton.citySelected = Singleton.cities[position]
                val intent = Intent(this@MainActivity, CityDetailsActivity::class.java)
                startActivity(intent)
            }

            override fun onCityLongClick(view: View, position: Int) {
                val deletedCity = Singleton.cities[position]
                Singleton.delete(deletedCity)
                binding.mainRecyclerView.adapter?.notifyItemRemoved(position)

                val snackbar = Snackbar.make(binding.root, "Item removido", Snackbar.LENGTH_LONG)
                snackbar.setAction("Desfazer") {
                    Singleton.cities.add(position, deletedCity)
                    binding.mainRecyclerView.adapter?.notifyItemInserted(position)
                    binding.mainRecyclerView.scrollToPosition(position)
                }
                snackbar.show()
            }
        })

        binding.mainRecyclerView.adapter = cityAdapter
        binding.mainRecyclerView.layoutManager = LinearLayoutManager(this)

        binding.addButton.setOnClickListener {
            Singleton.citySelected = null
            val intent = Intent(this, CityDetailsActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        binding.mainRecyclerView.adapter?.notifyDataSetChanged()
    }
}
